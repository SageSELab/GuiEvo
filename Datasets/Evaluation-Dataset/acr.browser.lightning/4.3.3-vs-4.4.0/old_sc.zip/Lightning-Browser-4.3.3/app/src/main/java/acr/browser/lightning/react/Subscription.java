package acr.browser.lightning.react;

public interface Subscription {

    void unsubscribe();

}

# androdns
Android DNS Client


Google Play: https://play.google.com/store/apps/details?id=androdns.android.leetdreams.ch.androdns


package androdns.android.leetdreams.ch.androdns;


public class DNSKEYUnavailableException extends Exception {
    public DNSKEYUnavailableException(){
        super();
    }
    public DNSKEYUnavailableException(String s){
        super(s);
    }
}

module.exports = {
  root: true,
  extends: '@react-native-community',
  comma-dangle: 0,
  radix: 'as-needed',
};

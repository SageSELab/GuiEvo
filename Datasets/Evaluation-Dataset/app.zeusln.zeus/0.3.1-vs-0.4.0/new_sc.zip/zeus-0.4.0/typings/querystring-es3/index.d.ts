declare module 'querystring-es3' {
    const querystring: any;
    export default querystring;
}

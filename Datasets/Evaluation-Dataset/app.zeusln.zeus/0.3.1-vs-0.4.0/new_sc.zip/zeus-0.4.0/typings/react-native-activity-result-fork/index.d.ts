declare module 'react-native-activity-result-fork' {
    const ActivityResult: any;
    export default ActivityResult;
}

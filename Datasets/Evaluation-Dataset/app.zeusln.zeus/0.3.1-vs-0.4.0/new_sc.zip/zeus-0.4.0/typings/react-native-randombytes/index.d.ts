declare module 'react-native-randombytes' {
    const randomBytes: any;
    export { randomBytes };
}

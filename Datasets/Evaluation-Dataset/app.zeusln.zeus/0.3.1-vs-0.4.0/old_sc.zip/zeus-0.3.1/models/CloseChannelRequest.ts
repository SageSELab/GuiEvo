export default interface CloseChannelRequest {
    funding_txid_str: string;
    output_index: string;
}

export default interface LoginRequest {
    login: string;
    password: string;
}

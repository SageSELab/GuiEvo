declare module 'identicon.js' {
    const Identicon: {
        new (value: string, seed: number): any;
    };

    export default Identicon;
}

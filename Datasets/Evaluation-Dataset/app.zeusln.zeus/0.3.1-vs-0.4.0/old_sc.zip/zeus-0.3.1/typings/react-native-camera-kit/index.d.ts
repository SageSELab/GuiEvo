declare module 'react-native-camera-kit' {
    const CameraKitCamera: any;
    const CameraKitCameraScreen: any;

    export { CameraKitCamera, CameraKitCameraScreen };
}

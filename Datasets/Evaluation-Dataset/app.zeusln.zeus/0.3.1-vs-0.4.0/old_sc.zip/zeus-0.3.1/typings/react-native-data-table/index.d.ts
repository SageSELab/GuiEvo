declare module 'react-native-data-table' {
    const Cell: any;
    const Header: any;
    const Row: any;

    export { Cell, Header, Row };
}

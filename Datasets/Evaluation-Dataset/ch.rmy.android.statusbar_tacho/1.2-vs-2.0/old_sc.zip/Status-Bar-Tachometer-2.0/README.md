# Status Bar Speedometer
A simple Android app that displays your current speed as a notification in the status bar.

It is toggleable through shortcuts and supports 4 different units:
- m/s
- km/h
- mi/h
- ft/s

Find the app here: https://play.google.com/store/apps/details?id=ch.rmy.android.statusbar_tacho

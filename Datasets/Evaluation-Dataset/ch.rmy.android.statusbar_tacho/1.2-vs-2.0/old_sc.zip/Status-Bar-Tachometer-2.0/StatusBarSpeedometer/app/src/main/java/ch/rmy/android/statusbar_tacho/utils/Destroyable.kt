package ch.rmy.android.statusbar_tacho.utils

interface Destroyable {

    fun destroy()

}

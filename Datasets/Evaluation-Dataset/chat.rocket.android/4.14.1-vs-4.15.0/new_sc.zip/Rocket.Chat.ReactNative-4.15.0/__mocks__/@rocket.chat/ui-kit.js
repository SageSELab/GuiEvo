export default {
	window: () => null
};

export const uiKitMessage = () => () => null;

export const uiKitModal = () => () => null;

export class UiKitParserMessage {}

export class UiKitParserModal {}

export class Sound {
	loadAsync = () => {};

	playAsync = () => {};

	pauseAsync = () => {};

	stopAsync = () => {};

	setOnPlaybackStatusUpdate = () => {};

	setPositionAsync = () => {};
}
export const Audio = { Sound };

const activateKeepAwake = () => '';
const deactivateKeepAwake = () => '';

export { activateKeepAwake, deactivateKeepAwake };

export default {
	openBrowserAsync: () => ''
};

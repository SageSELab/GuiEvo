export default {
	hide: () => ''
};

export const RectButton = ({ children }) => children;
export const State = () => 'View';
export const LongPressGestureHandler = ({ children }) => children;
export const BorderlessButton = ({ children }) => children;
export const PanGestureHandler = ({ children }) => children;

export default {
	NavigationActions: () => {}
};

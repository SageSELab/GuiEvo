package chat.rocket.reactnative;

import android.app.Application;

import com.facebook.react.ReactPackage;

import java.util.Arrays;
import java.util.List;

public class AdditionalModules {
    public List<ReactPackage> getAdditionalModules(Application application) {
        return Arrays.<ReactPackage>asList();
    }
}

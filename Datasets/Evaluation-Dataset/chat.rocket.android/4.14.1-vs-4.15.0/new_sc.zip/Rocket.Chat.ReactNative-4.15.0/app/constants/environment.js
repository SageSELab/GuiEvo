import RNConfigReader from 'react-native-config-reader';

export const isFDroidBuild = RNConfigReader.FDROID_BUILD;

export const isOfficial = RNConfigReader.IS_OFFICIAL;

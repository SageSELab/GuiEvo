export default {
	SENT: 0,
	TEMP: 1,
	ERROR: 2
};

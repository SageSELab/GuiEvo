export const PADDING_HORIZONTAL = 12;
export const BASE_HEIGHT = 46;

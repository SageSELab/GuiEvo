export const TYPE = {
	CHOOSE: 'choose',
	CONFIRM: 'confirm',
	ENTER: 'enter',
	LOCKED: 'locked'
};

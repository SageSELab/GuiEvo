import React from 'react';

const MessageContext = React.createContext();
export default MessageContext;

### How to remove ee folder

If you're willing to remove Enterprise Edition features from your app, follow this diff:
https://github.com/RocketChat/Rocket.Chat.ReactNative/compare/develop...no-ee?expand=1
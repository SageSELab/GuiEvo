export const THUMBS_HEIGHT = 74;

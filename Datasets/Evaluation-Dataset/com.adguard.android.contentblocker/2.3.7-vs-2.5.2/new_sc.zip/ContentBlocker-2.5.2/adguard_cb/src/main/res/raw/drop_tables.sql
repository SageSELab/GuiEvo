DROP TABLE IF EXISTS filter_lists;
DROP TABLE IF EXISTS filters_localization;
DROP TABLE IF EXISTS traffic_stats;
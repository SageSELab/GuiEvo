UPDATE filter_lists
   SET filter_name = '(Obsolete) Anti-Adblock Killer | Reek'
 WHERE filter_list_id = 211;
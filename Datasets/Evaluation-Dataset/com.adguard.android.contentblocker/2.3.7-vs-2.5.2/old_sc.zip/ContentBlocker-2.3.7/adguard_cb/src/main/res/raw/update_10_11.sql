INSERT INTO filter_lists (filter_list_id, filter_name, enabled, version, time_last_downloaded, time_updated, display_order) VALUES (13,'Turkish filter',0,'1.0.0.2',1444640204990,1444640204990,11);
INSERT INTO filters_localization (filter_list_id, language_code, filter_name) VALUES (13,'ru','Турецкий фильтр');
INSERT INTO filters_localization (filter_list_id, language_code, filter_name) VALUES (13,'en','Turkish filter');
INSERT INTO filters_localization (filter_list_id, language_code, filter_name) VALUES (13,'uk','Турецький фільтр');
package com.app.missednotificationsreminder.data

import dagger.Module

@Module
class DebugDataModule
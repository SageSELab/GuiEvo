package com.app.missednotificationsreminder.di.qualifiers

import javax.inject.Qualifier

@Qualifier
@Retention(AnnotationRetention.RUNTIME)
annotation class IsInstrumentationTest 
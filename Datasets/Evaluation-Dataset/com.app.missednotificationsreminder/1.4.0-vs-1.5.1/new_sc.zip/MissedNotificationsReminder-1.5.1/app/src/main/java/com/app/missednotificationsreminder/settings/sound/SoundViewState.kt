package com.app.missednotificationsreminder.settings.sound

data class SoundViewState(val ringtone: String, val ringtoneName: String)
package com.app.missednotificationsreminder.util.event;

/**
 * General event interface
 */
public interface Event {
}

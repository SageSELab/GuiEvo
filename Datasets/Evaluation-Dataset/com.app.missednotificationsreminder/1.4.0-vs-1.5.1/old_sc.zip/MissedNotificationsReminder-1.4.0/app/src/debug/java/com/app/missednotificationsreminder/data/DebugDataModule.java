package com.app.missednotificationsreminder.data;

import dagger.Module;

@Module(
        complete = false,
        library = true,
        overrides = true
)
public final class DebugDataModule {

}

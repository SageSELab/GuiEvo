package com.app.missednotificationsreminder.ui.view;

/**
 * Interval settings view interface
 *
 * @author Eugene Popovich
 */
public interface ReminderView {
}

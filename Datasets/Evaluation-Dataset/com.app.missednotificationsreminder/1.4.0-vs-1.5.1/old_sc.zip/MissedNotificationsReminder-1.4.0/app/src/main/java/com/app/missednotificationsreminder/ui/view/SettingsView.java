package com.app.missednotificationsreminder.ui.view;

/**
 * Other settings view interface
 *
 * @author Eugene Popovich
 */
public interface SettingsView {
}

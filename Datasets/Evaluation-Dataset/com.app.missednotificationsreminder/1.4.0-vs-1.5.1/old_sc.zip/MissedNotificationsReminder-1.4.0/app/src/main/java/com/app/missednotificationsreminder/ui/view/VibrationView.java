package com.app.missednotificationsreminder.ui.view;

/**
 * The virbration settings view interface
 */
public interface VibrationView {
    void vibrate();
}

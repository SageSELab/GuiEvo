ToneDef
=======

Original Google Play blurb:
>ToneDef is a small, but powerful tone dialer application for Android featuring DTMF, bluebox, and redbox tone generation. Use the keypad, enter a predefined sequence, or select an entry from your contact list.
>
>There are other tone generators on the market, but when I really needed one...well... I was left with the urge to write my own. Hopefully this one works out for you, too. ;)"

The code for ToneDef is now open source, under the GPL V2 license.  

Many MANY thanks to the handful of you who picked up the ad-free version of the application.

Latest official build available on Google Play: https://play.google.com/store/apps/details?id=com.bytestemplar.tonedef

package com.sujitech.tessercubecore.common

import org.ocpsoft.prettytime.PrettyTime

val prettyTime by lazy {
    PrettyTime()
}
package com.sujitech.tessercubecore.common

import android.app.Application

object DataTracking {
    fun init(app: Application) {
        // Do nothing
    }
    fun track(name: String, data: Map<String, String>) {
        // Do nothing
    }
}
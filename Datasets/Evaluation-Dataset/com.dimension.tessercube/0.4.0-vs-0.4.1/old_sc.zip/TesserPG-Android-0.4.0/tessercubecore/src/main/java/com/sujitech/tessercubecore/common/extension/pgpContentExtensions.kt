package com.sujitech.tessercubecore.common.extension

//
//val String.isPGPMessage
//    get() =
//        (this.startsWith(appContext.getString(R.string.pgp_message_start))
//                && this.endsWith(appContext.getString(R.string.pgp_message_end)))
//                || (this.startsWith(appContext.getString(R.string.pgp_signed_message_start))
//                && this.endsWith(appContext.getString(R.string.pgp_signed_message_end)))
//
//
//val String.isPGPPublicKey
//    get() = this.startsWith(appContext.getString(R.string.pgp_public_key_start)) && this.endsWith(appContext.getString(R.string.pgp_public_key_end))
//
//val String.isPGPPrivateKey
//    get() = this.startsWith(appContext.getString(R.string.pgp_private_key_start)) && this.endsWith(appContext.getString(R.string.pgp_private_key_end))

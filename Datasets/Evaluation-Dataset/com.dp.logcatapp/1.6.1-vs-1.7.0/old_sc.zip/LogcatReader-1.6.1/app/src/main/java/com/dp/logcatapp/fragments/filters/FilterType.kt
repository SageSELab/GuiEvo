package com.dp.logcatapp.fragments.filters

object FilterType {
    const val KEYWORD = 0
    const val TAG = 1
    const val PID = 2
    const val TID = 3
    const val LOG_LEVELS = 4
}
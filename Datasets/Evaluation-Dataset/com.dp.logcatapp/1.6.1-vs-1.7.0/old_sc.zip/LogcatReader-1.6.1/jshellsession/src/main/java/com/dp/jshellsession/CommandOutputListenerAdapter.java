/*
 * Copyright (c) 2017 Darshan Parajuli
 */

package com.dp.jshellsession;

public class CommandOutputListenerAdapter implements OnCommandOutputListener {

    @Override
    public void onNewStdOutLine(String line) {
    }

    @Override
    public void onNewErrOutLine(String line) {
    }
}

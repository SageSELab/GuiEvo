# Simple-Accounting
Android app that helps you balance.

[<img src="https://f-droid.org/badge/get-it-on.png"
      alt="Get it on F-Droid"
      height="80">](https://f-droid.org/packages/com.emmanuelmess.simpleaccounting/)
[<img src="https://play.google.com/intl/en_us/badges/images/generic/en-play-badge.png"
      alt="Get it on Google Play"
      height="80">](https://play.google.com/store/apps/details?id=com.emmanuelmess.simpleaccounting)

### Donating: 
Bitcoin: 1HFhPxH9bqMKvs44nHqXjEEPC2m7z1V8tW

## Screenshots

### Main
<img src="Screenshot_1491862500.png" data-canonical-src="Screenshot_1491862500.png" height="350" /> <img src="Screenshot_1491862506.png" data-canonical-src="Screenshot_1491862506.png" height="350" /> <img src="Screenshot_1491945273.png" data-canonical-src="Screenshot_1491945273.png" height="350" /> <img src="Screenshot_1491945294.png" data-canonical-src="Screenshot_1491945294.png" height="350" />

### Settings
<img src="Screenshot_1491862511.png" data-canonical-src="Screenshot_1491862511.png" height="350" /> <img src="Screenshot_1491945261.png" data-canonical-src="Screenshot_1491945261.png" height="350" /> <img src="Screenshot_1491945267.png" data-canonical-src="Screenshot_1491945267.png" height="350" />

### Month selection
<img src="Screenshot_1491945314.png" data-canonical-src="Screenshot_1491945314.png" height="350" />

### Printing
<img src="Screenshot_1491945299.png" data-canonical-src="Screenshot_1491945299.png" height="350" />

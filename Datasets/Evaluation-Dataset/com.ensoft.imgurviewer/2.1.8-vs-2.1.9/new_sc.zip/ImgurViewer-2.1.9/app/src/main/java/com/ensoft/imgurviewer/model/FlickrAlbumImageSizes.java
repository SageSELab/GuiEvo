package com.ensoft.imgurviewer.model;

public class FlickrAlbumImageSizes
{
	FlickrAlbumImageSize c;
	
	FlickrAlbumImageSize h;
	
	FlickrAlbumImageSize k;
	
	FlickrAlbumImageSize l;
	
	FlickrAlbumImageSize m;
	
	FlickrAlbumImageSize n;
	
	FlickrAlbumImageSize q;
	
	FlickrAlbumImageSize s;
	
	FlickrAlbumImageSize t;
	
	FlickrAlbumImageSize z;
	
	FlickrAlbumImageSize sq;
}

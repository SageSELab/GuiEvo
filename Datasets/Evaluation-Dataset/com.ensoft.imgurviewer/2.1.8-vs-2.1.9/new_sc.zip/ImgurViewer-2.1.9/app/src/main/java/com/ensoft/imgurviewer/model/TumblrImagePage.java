package com.ensoft.imgurviewer.model;

import com.google.gson.annotations.SerializedName;

public class TumblrImagePage
{
	@SerializedName( "photo" )
	public TumblrImageResponse photo;
}

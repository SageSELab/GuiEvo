package com.ensoft.imgurviewer.model;

import com.google.gson.annotations.SerializedName;

public class TwitchClipResponse
{
	@SerializedName( "data" )
	public TwitchClipData data;
}

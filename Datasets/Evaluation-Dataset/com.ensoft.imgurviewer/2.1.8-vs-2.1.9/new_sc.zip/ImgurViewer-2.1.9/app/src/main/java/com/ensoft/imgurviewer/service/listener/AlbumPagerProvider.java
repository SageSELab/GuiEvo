package com.ensoft.imgurviewer.service.listener;

public interface AlbumPagerProvider
{
	int getCurrentPage();
}

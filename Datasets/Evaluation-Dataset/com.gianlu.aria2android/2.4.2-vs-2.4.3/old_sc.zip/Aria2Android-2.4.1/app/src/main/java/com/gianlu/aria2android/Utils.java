package com.gianlu.aria2android;

public final class Utils {
    public static final String LABEL_SESSION_DURATION = "session_duration";
    public static final String ACTION_TURN_ON = "aria2_on";
    public static final String ACTION_TURN_OFF = "aria2_off";

    private Utils() {
    }
}
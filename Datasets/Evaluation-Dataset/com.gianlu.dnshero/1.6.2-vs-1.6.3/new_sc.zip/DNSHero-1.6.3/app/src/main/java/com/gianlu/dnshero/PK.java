package com.gianlu.dnshero;

import com.gianlu.commonutils.preferences.CommonPK;
import com.gianlu.commonutils.preferences.Prefs;

public class PK extends CommonPK {
    public static final Prefs.Key FAVORITES = new Prefs.Key("favoriteDomains");
}

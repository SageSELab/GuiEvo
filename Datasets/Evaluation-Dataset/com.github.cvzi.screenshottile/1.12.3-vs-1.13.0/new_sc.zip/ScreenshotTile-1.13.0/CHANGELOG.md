# Changelog

## 1.13.0
*   Close button can be any emoji e.g. ❌ ✅ ❎ ✓ ✔ ⛌ ✖ #56
*   Ukrainian translation by [@Sensetivity](https://github.com/Sensetivity)
*   French translation by [@UncleReaton](https://github.com/UncleReaton)
*   Fix: white font on Android 24-28
*   Tile action: screenshot or partial screenshot #55
*   Use dedicated foreground service for media projection if tile service is not in foreground
*   Fix: partial screenshot rectangle was not correct if there was a cutout or visible status bar
*   Switch dark theme in settings #65
*   Extra delay for floating buttton #59
*   Show a settings button for 2s after drag & drop of floating button
## 1.12.3
*   Hungarian translation by Stefi68
*   Russian translation by rikishi0071
*   Preference layout moved to the left
## 1.12.2
*   Updated Chinese app store translation. Thanks to [@linsui](https://github.com/linsui)
## 1.12.1
*   Added Italian translation. Thanks to [Filippo "Tecnophil" Cervellera](https://twitter.com/Tecnophil)
*   Improved Arabic translation
*   Improved Ukrainian translation
## 1.12.0
*   Android 11: native method with custom storage folder [#43](https://github.com/cvzi/ScreenshotTile/issues/43)
*   Icon color changed
## 1.11.0
*   Enable native method on new installs
*   Permissions management improved
*   Shortcut to toggle floating button
*   Square or round shutter for floating button with animations
*   Completely translated to Portuguese. Thanks to [@mezysinc](https://github.com/mezysinc)
*   Russian translation improved
*   Fix "hide app icon"
*   Add dimension metadata to MediaStore
*   Hide floating button before taking a screenshot
*   Wait longer for quick settings panel to collapse on native method
## 1.10.0
*   Added floating button to take screenshots
*   Added initial activity with text explanation of features
*   Added Portuguese pt-br translation. Thanks to [@mezysinc](https://github.com/mezysinc)
*   Rename package
*   Design improvements
## 1.9.0
*   Added widgets
*   Improvements for Android Q and 11. Start foreground service earlier
## 1.8.6
*   Update Kotlin
## 1.8.5
*   Improvements for Android Q and 11
## 1.8.4
*   some phones show the permission dialog in the screenshot. Added a delay to avoid it
## 1.8.3
*   gradle.properties: android.useAndroidX=true
## 1.8.2
*   Bugfix: [sdcard error after reboot](https://github.com/cvzi/ScreenshotTile/issues/24)
*   Remove "hide app icon" on Android Q. [It's no longer supported since Android 10+](https://github.com/cvzi/ScreenshotTile/issues/25)
## 1.8.1
*   Bugfix: Edit did not work with custom storage location and Google Photos app
## 1.8.0
*   Added support for a custom storage location
## 1.7.1
*   Updated Chinese translations. Thanks to [@linsui](https://github.com/linsui)
*   Several bugfixes
## 1.7.0
*   Simulate Home+Power button press to use native/system screenshot function. Requires enabled accessibility service and Android Pie/9+
## 1.6.5
*   Updated Indonesian translation. Thanks to [@alexschenider](https://github.com/alexschenider/)
## 1.6.4
*   Support night mode on Android Q
*   Disable back gesture on viewpager on Android Q
## 1.6.3
*   Updated Indonesian translation. Thanks to [@alexschenider](https://github.com/alexschenider/)
## 1.6.2
*   Updated translations
*   Compressed images and removed unused resources
## 1.6.1
*   Updated Indonesian translation. Thanks to [@alexschenider](https://github.com/alexschenider/)
*   Added short text to each tutorial screenshot
## 1.6.0
*   Added an option in the long-press menu to select an area before taking a screenshot
*   Added a Broadcast receiver for broadcast intents from other apps like MacroDroid
## 1.5.4
*   Fixed: Delete from notification on Android Q
## 1.5.3
*   Enhancements for Android Q
## 1.5.2
*   Bugfix
## 1.5.1
*   Added Polish translation
*   Translations improved
*   Small bugfix
## 1.5.0
*   Added settings entry for notifications
*   Moved Fragments and Preference to androidx/AppCompat
*   Translations improved
## 1.4.0
*   Redesigned the notification with a big picture and reordered the buttons
*   Added a list of open source projects used to the about section
*   Allow installation to internal storage only
*   Improved existing translations
*   Added incomplete translations for Arabic, Bengali, Gujarati, Hindi, Japanese, Kannada, Malay, Marathi, Persian, Portuguese, Punjabi, Russian, Tamil, Telugu, Thai, Uighur, Urdu, Vietnamese
*   Update gradle
## 1.3.3
*   Removed black borders on screenshots with some devices
*   Fix some nullable crashes
*   Update Kotlin version
## 1.3.2
*   Added file format: png, jpg, webp
*   Moved compressing the bitmap to file in separate thread
## 1.3.0
*   Added "Edit" button
## 1.2.4
*   Added [fastlane](https://docs.fastlane.tools/actions/supply/#images-and-screenshots) metadata
## 1.2.3
*   Fix crash (java.lang.OutOfMemoryError) in the tutorial
## 1.2.2
*   Update gradle
## 1.2.1
*   Fix crash (java.io.IOException) at java.io.File.createNewFile
## 1.2.0
*   Added tutorial with icon on home screen (Option to hide icon in settings)
*   Tile state is now always off
*   Fixed crash (java.lang.IllegalStateException at ScreenshotTileService.onTileAdded)
*   Added app icon shortcut to take a screenshot
*   Fixed bug: countdown/wait before screenshot was creating two screenshots
*   Disabled proguard
*   Translated about section
*   Added Tagalog/filipino translation
## 1.1.0
*   Added "Share" and "Delete" button to the notification
*   Fixed crash when permissions were initially denied or canceled
*   Fixed bug: countdown/wait before screenshot was creating two screenshots
## 1.0.2
*   Fixed Hebrew translation.
## 1.0.1
*   Added Simplified Chinese translation. Thanks to [@linsui](https://github.com/linsui)
*   Added Norwegian translation.
*   Added Spanish translation.
*   Added Hebrew translation.
*   Added French translation.
*   Added German translation.

package com.github.cvzi.screenshottile.interfaces;

public interface OnAcquireScreenshotPermissionListener {
    void onAcquireScreenshotPermission(boolean isNewPermission);
}

#v1.1.0

- OPML import/export for local account
- Dark theme
- Share or download item image
- Open item in webview
- Minor bug fixes and improvements

#v1.0.2.2

Disable Proguard as it makes fail some functionalities.

#v1.0.2.1

Fix a crash related to Proguard Rules.

#v1.0.2

 - Add swipe background to main list items
 - Add preference to parse a fixed number of items when adding a local feed
 - Change feed/folders way to interact
 - Minor bug fixes and improvements


 
# v1.0.1
 
# v1.0 Initial release

- Local RSS parsing 
- RSS 2.0, ATOM and JSON formats support 
- Multiple accounts 
- Feeds and folders management (create, update and delete feeds/folders if your service API supports it)
- Nextcloud news support 
- FreshRSS support
package com.readrops.app.utils;

import androidx.annotation.NonNull;

import com.bumptech.glide.module.AppGlideModule;

@com.bumptech.glide.annotation.GlideModule
public class GlideModule extends AppGlideModule {

}

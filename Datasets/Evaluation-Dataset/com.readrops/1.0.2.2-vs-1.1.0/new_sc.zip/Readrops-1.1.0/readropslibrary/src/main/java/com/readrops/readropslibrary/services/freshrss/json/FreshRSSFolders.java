package com.readrops.readropslibrary.services.freshrss.json;

import java.util.List;

public class FreshRSSFolders {

    private List<FreshRSSFolder> tags;

    public List<FreshRSSFolder> getTags() {
        return tags;
    }

    public void setTags(List<FreshRSSFolder> tags) {
        this.tags = tags;
    }
}

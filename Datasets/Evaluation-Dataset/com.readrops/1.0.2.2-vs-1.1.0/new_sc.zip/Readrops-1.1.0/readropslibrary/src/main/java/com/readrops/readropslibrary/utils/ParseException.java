package com.readrops.readropslibrary.utils;

public class ParseException extends Exception {

}

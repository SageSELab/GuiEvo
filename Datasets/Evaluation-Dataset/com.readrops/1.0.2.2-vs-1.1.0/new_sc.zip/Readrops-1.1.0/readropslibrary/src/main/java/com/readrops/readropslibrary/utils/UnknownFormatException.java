package com.readrops.readropslibrary.utils;

public class UnknownFormatException extends Exception {

    public UnknownFormatException() {

    }

    public UnknownFormatException(String message) {
        super(message);
    }
}

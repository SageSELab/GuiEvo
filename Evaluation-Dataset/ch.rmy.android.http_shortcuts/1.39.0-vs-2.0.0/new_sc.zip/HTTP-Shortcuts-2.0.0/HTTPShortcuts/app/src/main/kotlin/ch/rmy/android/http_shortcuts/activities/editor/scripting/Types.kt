package ch.rmy.android.http_shortcuts.activities.editor.scripting

typealias InsertText = (before: String, after: String) -> Unit

package ch.rmy.android.http_shortcuts.http

class ErrorResponse(val shortcutResponse: ShortcutResponse) : Exception()
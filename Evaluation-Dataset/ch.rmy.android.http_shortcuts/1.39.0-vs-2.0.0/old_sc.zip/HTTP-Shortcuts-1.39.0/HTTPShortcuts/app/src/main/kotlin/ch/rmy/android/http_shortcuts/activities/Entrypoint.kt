package ch.rmy.android.http_shortcuts.activities

interface Entrypoint

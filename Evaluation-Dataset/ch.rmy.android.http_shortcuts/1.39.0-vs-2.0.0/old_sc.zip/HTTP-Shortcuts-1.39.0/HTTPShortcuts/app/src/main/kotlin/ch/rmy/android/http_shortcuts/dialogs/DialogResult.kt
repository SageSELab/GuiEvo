package ch.rmy.android.http_shortcuts.dialogs

enum class DialogResult {
    OK,
    CANCELED,
    NOT_SHOWN,
}
package ch.rmy.android.http_shortcuts.exceptions

class ResumeLaterException : Throwable()
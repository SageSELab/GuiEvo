package ch.rmy.android.http_shortcuts.import_export

class ImportException(override val message: String) : Exception(message)
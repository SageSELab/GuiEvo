package ch.rmy.android.http_shortcuts.utils

import android.widget.SeekBar

open class SimpleOnSeekBarChangeListener : SeekBar.OnSeekBarChangeListener {

    override fun onProgressChanged(slider: SeekBar, progress: Int, fromUser: Boolean) {

    }

    override fun onStartTrackingTouch(slider: SeekBar) {

    }

    override fun onStopTrackingTouch(slider: SeekBar) {

    }
}
package ch.rmy.android.http_shortcuts.variables

class VariablePlaceholder(val variableId: String, val variableKey: String)

package ch.rmy.android.http_shortcuts.variables

import ch.rmy.android.http_shortcuts.utils.ColoredSpan

class VariableSpan(color: Int, val variableId: String) : ColoredSpan(color)
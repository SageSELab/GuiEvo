package com.ensoft.imgurviewer.model;

import com.google.gson.annotations.SerializedName;

public class TumblrMedia
{
	@SerializedName( "ImagePage" )
	public TumblrImagePage imagePage;
}

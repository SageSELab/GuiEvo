package com.ensoft.imgurviewer.model;

import com.google.gson.annotations.SerializedName;

public class XHamsterVideo
{
	@SerializedName( "videoModel" )
	public XHamsterVideoModel xHamsterVideoModel;
}

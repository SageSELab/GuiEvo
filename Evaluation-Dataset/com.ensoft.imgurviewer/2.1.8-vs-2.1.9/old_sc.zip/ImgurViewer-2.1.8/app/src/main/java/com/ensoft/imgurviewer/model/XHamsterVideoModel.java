package com.ensoft.imgurviewer.model;

import com.google.gson.annotations.SerializedName;

public class XHamsterVideoModel
{
	@SerializedName( "sources" )
	public XHamsterVideoSources xHamsterVideoSources;
}

package com.github.gotify.messages.provider;

import com.github.gotify.client.model.Message;

public class MessageWithImage {
    public Message message;
    public String image;
}


# Health

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**database** | **String** | The health of the database connection. | 
**health** | **String** | The health of the overall application. | 




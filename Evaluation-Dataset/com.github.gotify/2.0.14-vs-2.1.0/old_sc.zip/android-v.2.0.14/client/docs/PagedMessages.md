
# PagedMessages

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**messages** | [**List&lt;Message&gt;**](Message.md) | The messages. | 
**paging** | [**Paging**](Paging.md) |  | 




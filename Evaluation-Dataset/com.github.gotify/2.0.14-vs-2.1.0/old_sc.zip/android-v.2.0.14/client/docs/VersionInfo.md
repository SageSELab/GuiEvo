
# VersionInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**buildDate** | **String** | The date on which this binary was built. | 
**commit** | **String** | The git commit hash on which this binary was built. | 
**version** | **String** | The current version. | 




 
# 1.0 Initial release

- Local RSS parsing 
- RSS 2.0, ATOM and JSON formats support 
- Multiple accounts 
- Feeds and folders management (create, update and delete feeds/folders if your service API supports it)
- Nextcloud news support 
- FreshRSS support
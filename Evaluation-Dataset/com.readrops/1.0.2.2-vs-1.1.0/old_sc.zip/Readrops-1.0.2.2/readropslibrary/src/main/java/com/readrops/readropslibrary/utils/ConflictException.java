package com.readrops.readropslibrary.utils;

public class ConflictException extends Exception {

    public ConflictException() {

    }

    public ConflictException(String message) {
        super(message);
    }
}

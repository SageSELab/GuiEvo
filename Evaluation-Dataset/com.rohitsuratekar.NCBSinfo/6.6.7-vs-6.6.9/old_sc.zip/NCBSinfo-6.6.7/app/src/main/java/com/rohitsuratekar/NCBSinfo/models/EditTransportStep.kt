package com.rohitsuratekar.NCBSinfo.models

class EditTransportStep {
    var number: Int = 0
    var isComplete: Boolean = false
    var isSeen: Boolean = false
    var text: Int = 0
}
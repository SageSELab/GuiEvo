Changelog
==========

Version 1.3 *(2016-12-11)*
----------------------------

 * Support of CyangenMod added

Version 1.2 *(2016-11-12)*
----------------------------

 * Design-Update
 * New Logo
 * Integration of permission request

Version 1.1 *(2016-01-23)*
----------------------------

 * Renaming of Packages

Version 1.0 *(2015-10-15)*
----------------------------

 * Initial Release

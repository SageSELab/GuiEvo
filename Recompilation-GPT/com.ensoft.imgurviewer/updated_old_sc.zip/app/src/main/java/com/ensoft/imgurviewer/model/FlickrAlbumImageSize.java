package com.ensoft.imgurviewer.model;

public class FlickrAlbumImageSize
{
	public int width;
	
	public int height;
	
	public String displayUrl;
	
	public String url;
	
	public String key;
}

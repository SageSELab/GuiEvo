package com.ensoft.imgurviewer.model;

import com.google.gson.annotations.SerializedName;

public class GfycatResource
{
	@SerializedName( "gfyItem" )
	public GfycatVideo item;
}

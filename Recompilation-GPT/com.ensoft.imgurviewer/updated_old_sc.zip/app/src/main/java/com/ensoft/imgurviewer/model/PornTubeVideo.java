package com.ensoft.imgurviewer.model;

public class PornTubeVideo
{
	public String status;
	
	public String token;
}

package com.ensoft.imgurviewer.model;

public class TumblrSizes
{
	protected String id;
	
	protected int width;
	
	protected int height;
	
	public String getId()
	{
		return id;
	}
	
	public int getWidth()
	{
		return width;
	}
	
	public int getHeight()
	{
		return height;
	}
}

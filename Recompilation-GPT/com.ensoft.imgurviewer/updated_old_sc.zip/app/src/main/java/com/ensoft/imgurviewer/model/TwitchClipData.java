package com.ensoft.imgurviewer.model;

import com.google.gson.annotations.SerializedName;

public class TwitchClipData
{
	@SerializedName( "clip" )
	public TwitchClips clip;
}

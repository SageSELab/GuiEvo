package com.ensoft.imgurviewer.model;

import com.google.gson.annotations.SerializedName;

public class XHamsterVideoSources
{
	@SerializedName( "mp4" )
	public XHamsterVideoMp4 xHamsterVideoMp4;
}

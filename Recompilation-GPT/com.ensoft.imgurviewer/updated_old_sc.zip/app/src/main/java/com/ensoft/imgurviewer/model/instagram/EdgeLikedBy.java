
package com.ensoft.imgurviewer.model.instagram;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class EdgeLikedBy {

    @SerializedName("count")
    @Expose
    public long count;

}

package com.readrops.readropslibrary.services;

public enum SyncType {
    INITIAL_SYNC,
    CLASSIC_SYNC
}

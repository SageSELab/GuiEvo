
# Error

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **String** | The general error message | 
**errorCode** | **Long** | The http error code. | 
**errorDescription** | **String** | The http error code. | 




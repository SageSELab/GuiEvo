
# UserPass

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pass** | **String** | The user password. For login. | 





# UserWithPass

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**admin** | **Boolean** | If the user is an administrator. |  [optional]
**id** | **Long** | The user id. | 
**name** | **String** | The user name. For login. | 
**pass** | **String** | The user password. For login. | 



